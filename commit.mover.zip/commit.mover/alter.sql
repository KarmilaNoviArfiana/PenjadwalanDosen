ALTER TABLE `kegiatan`
ADD `reminder` int NULL DEFAULT '0';